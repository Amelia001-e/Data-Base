import Funciones.Menu as mn
from Funciones.Menu import menu_registro_estudiantes
from Funciones.Menu import mostrar_menu_principal
from Funciones.Menu import mostrar_menu_registro
from Funciones.Menu import cargar_datos
from Funciones.Menu import guardar_datos
from Funciones.Menu import crear_estudiante
from Funciones.Menu import eliminar_estudiante
from Funciones.Menu import actualizar_estudiante
from Funciones.Menu import buscar_estudiante
from Funciones.Menu import mostrar_datos

from config.conDIC import crear_estudiante
from config.conSQL import estudiantessql
import config.conMongo as mg

client, db, collection = mg.conexion_mongo("control_estudiantes", "estudiantes")

# Lista usada en el diccionario
lista = []


mn.main()