from config.conDIC import crear_estudiante
from config.conSQL import estudiantessql
import config.conMongo as mg

client, db, collection = mg.conexion_mongo("control_estudiantes", "estudiantes")

# Lista usada en el diccionario
lista = []

nombre = input("Ingrese el nombre del Alumno: ").lower()
encargado = input("Ingrese el nombre del Encargado: ").lower()
grado = input("Ingrese el nombre del grado: ").lower()

# INSERTAR DATOS EN LISTA
lista.append(crear_estudiante(nombre, encargado, grado))
print(lista)

# INSERTAR DATOS EN SQL
estudiantessql(nombre, encargado, grado)
print(f"\nLos datos del alumno: {nombre} han sido insertados en SQL")

# INSERTAR DATOS EN MONGO
# Diccionario usado para insertar en Mongo
mongo = {
    "nombre": nombre,
    "encargado": encargado,
    "grado": grado
}

# Insertar el diccionario en MongoDB
mg.estudianteMongo(collection, mongo)
print(f"El alumno {nombre} ha sido insertado en MongoDB")
