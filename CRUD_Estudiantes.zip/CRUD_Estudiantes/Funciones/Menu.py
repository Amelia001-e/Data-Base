import sys
import csv

# PRUEBA DE LA PRUEBA 3 (Funcional)

# Tupla de grados disponibles
GRADOS_DISPONIBLES = ('Primaria', 'Basicos', 'Bachiller')

# Diccionario para almacenar estudiantes
estudiantes = {}

# Diccionario para almacenar notas
notas = {}

# Archivo CSV donde se almacenarán los datos de estudiantes
archivo_csv_estudiantes = 'estudiantes.csv'
# Archivo CSV donde se almacenarán las notas
archivo_csv_notas = 'notas.csv'


def cargar_datos_estudiantes():
    """Carga los datos de estudiantes desde el archivo CSV al diccionario de estudiantes."""
    global estudiantes
    try:
        with open(archivo_csv_estudiantes, mode='r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                codigo = row['Codigo']
                estudiantes[codigo] = {
                    'Nombre': row['Nombre'],
                    'Encargado': row['Encargado'],
                    'Grado': row['Grado']
                }
    except FileNotFoundError:
        # Si el archivo no existe, no hay datos que cargar
        pass


def guardar_datos_estudiantes():
    """Guarda los datos del diccionario de estudiantes en el archivo CSV."""
    with open(archivo_csv_estudiantes, mode='w', newline='') as file:
        fieldnames = ['Codigo', 'Nombre', 'Encargado', 'Grado']
        writer = csv.DictWriter(file, fieldnames=fieldnames)

        writer.writeheader()
        for codigo, datos in estudiantes.items():
            writer.writerow({
                'Codigo': codigo,
                'Nombre': datos['Nombre'],
                'Encargado': datos['Encargado'],
                'Grado': datos['Grado']
            })


def cargar_datos_notas():
    """Carga los datos de notas desde el archivo CSV al diccionario de notas."""
    global notas
    try:
        with open(archivo_csv_notas, mode='r', newline='') as file:
            reader = csv.DictReader(file)
            for row in reader:
                codigo = row['Codigo']
                materia = row['Materia']
                notas[codigo] = notas.get(codigo, {})
                notas[codigo][materia] = float(row['Nota'])
    except FileNotFoundError:
        # Si el archivo no existe, no hay datos que cargar
        pass


def guardar_datos_notas():
    """Guarda los datos del diccionario de notas en el archivo CSV."""
    with open(archivo_csv_notas, mode='w', newline='') as file:
        fieldnames = ['Codigo', 'Materia', 'Nota']
        writer = csv.DictWriter(file, fieldnames=fieldnames)

        writer.writeheader()
        for codigo, materias in notas.items():
            for materia, nota in materias.items():
                writer.writerow({
                    'Codigo': codigo,
                    'Materia': materia,
                    'Nota': nota
                })


def mostrar_menu_principal():
    print("\nCONTROL DE ESTUDIANTES")
    print("\n--- Menu Principal ---")
    print("1. Registro de Estudiantes")
    print("2. Control de Notas")
    print("3. Salir")


def mostrar_menu_registro():
    print("\n--- Menu Registro de Estudiantes ---")
    print("1. Crear")
    print("2. Eliminar")
    print("3. Actualizar")
    print("4. Buscar")
    print("5. Mostrar Datos")
    print("6. Regresar")


def crear_estudiante():
    print("\n--- Crear Estudiante ---")
    codigo = input("Codigo de Estudiantes: ")
    nombre = input("Nombre del alumno: ")
    encargado = input("Nombre del Encargado: ")
    grado = input("Grado o nivel académico: ")

    if grado not in GRADOS_DISPONIBLES:
        print("Grado no válido. Los grados disponibles son:", ', '.join(GRADOS_DISPONIBLES))
        return

    if codigo in estudiantes:
        print("El estudiante ya existe.")
    else:
        estudiantes[codigo] = {'Nombre': nombre, 'Encargado': encargado, 'Grado': grado}
        guardar_datos_estudiantes()  # Guardar los datos en el archivo CSV
        print("Estudiante creado exitosamente.")


def eliminar_estudiante():
    print("\n--- Eliminar Estudiante ---")
    opcion = input("Eliminar por (C)odigo o (N)ombre: ").strip().upper()

    if opcion == 'C':
        codigo = input("Codigo de Estudiantes: ")
        if codigo in estudiantes:
            del estudiantes[codigo]
            if codigo in notas:
                del notas[codigo]  # Eliminar también las notas del estudiante
            guardar_datos_estudiantes()  # Guardar los datos en el archivo CSV
            guardar_datos_notas()  # Guardar los datos de notas en el archivo CSV
            print("Estudiante eliminado exitosamente.")
        else:
            print("El estudiante no existe.")
    elif opcion == 'N':
        nombre = input("Nombre del Alumno: ")
        claves_a_eliminar = [codigo for codigo, datos in estudiantes.items() if datos['Nombre'] == nombre]

        if claves_a_eliminar:
            for clave in claves_a_eliminar:
                del estudiantes[clave]
                if clave in notas:
                    del notas[clave]  # Eliminar también las notas del estudiante
            guardar_datos_estudiantes()  # Guardar los datos en el archivo CSV
            guardar_datos_notas()  # Guardar los datos de notas en el archivo CSV
            print("Estudiantes eliminados exitosamente.")
        else:
            print("No se encontraron estudiantes con ese nombre.")
    else:
        print("Opción no válida.")


def actualizar_estudiante():
    print("\n--- Actualizar Estudiante ---")
    codigo = input("Codigo del alumno a actualizar: ")
    if codigo in estudiantes:
        print("Datos actuales:")
        info = estudiantes[codigo]
        print(f"Nombre del Alumno: {info['Nombre']}")
        print(f"Nombre del Encargado: {info['Encargado']}")
        print(f"Grado o nivel académico: {info['Grado']}")

        nombre = input("Nuevo nombre del Alumno (dejar en blanco para no cambiar): ")
        encargado = input("Nuevo nombre del Encargado (dejar en blanco para no cambiar): ")
        grado = input("Nuevo grado o nivel académico (dejar en blanco para no cambiar): ")

        if grado and grado not in GRADOS_DISPONIBLES:
            print("Grado no válido. Los grados disponibles son:", ', '.join(GRADOS_DISPONIBLES))
            return

        if nombre:
            info['Nombre'] = nombre
        if encargado:
            info['Encargado'] = encargado
        if grado:
            info['Grado'] = grado

        estudiantes[codigo] = info
        guardar_datos_estudiantes()  # Guardar los datos en el archivo CSV
        print("Estudiante actualizado exitosamente.")
    else:
        print("El estudiante no existe.")


def buscar_estudiante():
    print("\n--- Buscar Estudiante ---")
    criterio = input("Buscar por (C)odigo, (N)ombre o (G)rado: ").strip().upper()

    if criterio == 'C':
        codigo = input("Codigo de Estudiante: ")
        if codigo in estudiantes:
            info = estudiantes[codigo]
            print(f"Nombre del Alumno: {info['Nombre']}")
            print(f"Nombre del Encargado: {info['Encargado']}")
            print(f"Grado o nivel académico: {info['Grado']}")
        else:
            print("El estudiante no existe.")
    elif criterio == 'N':
        nombre = input("Nombre del Alumno: ")
        encontrados = [datos for datos in estudiantes.values() if datos['Nombre'] == nombre]

        if encontrados:
            for datos in encontrados:
                print(f"Nombre del Alumno: {datos['Nombre']}")
                print(f"Nombre del Encargado: {datos['Encargado']}")
                print(f"Grado o nivel académico: {datos['Grado']}")
                print("---")
        else:
            print("No se encontraron estudiantes con ese nombre.")
    elif criterio == 'G':
        grado = input("Grado o nivel académico: ")
        if grado not in GRADOS_DISPONIBLES:
            print("Grado no válido. Los grados disponibles son:", ', '.join(GRADOS_DISPONIBLES))
            return

        encontrados = [datos for datos in estudiantes.values() if datos['Grado'] == grado]

        if encontrados:
            for datos in encontrados:
                print(f"Nombre del Alumno: {datos['Nombre']}")
                print(f"Nombre del Encargado: {datos['Encargado']}")
                print(f"Grado o nivel académico: {datos['Grado']}")
                print("---")
        else:
            print("No se encontraron estudiantes en ese grado.")
    else:
        print("Opción no válida.")


def mostrar_datos():
    print("\n--- Mostrar Datos ---")
    if estudiantes:
        print(f"{'Codigo del Alumno':<25} {'Nombre del Alumno':<25} {'Nombre del Encargado':<25} {'Grado':<15}")
        print("=" * 95)
        for codigo, datos in estudiantes.items():
            print(f"{codigo:<25} {datos['Nombre']:<25} {datos['Encargado']:<25} {datos['Grado']:<15}")
    else:
        print("No hay datos para mostrar.")


def agregar_nota():
    print("\n--- Crear ---")
    codigo = input("Codigo del Estudiante: ")
    materia = input("Materia: ")
    try:
        nota = float(input("Nota: "))
    except ValueError:
        print("Nota inválida. Debe ser un número.")
        return

    if codigo in estudiantes:
        if codigo not in notas:
            notas[codigo] = {}
        notas[codigo][materia] = nota
        guardar_datos_notas()  # Guardar las notas en el archivo CSV
        print("Nota agregada exitosamente.")
    else:
        print("El estudiante no existe.")


def eliminar_nota():
    print("\n--- Eliminar  ---")
    criterio = input("Eliminar por (C)odigo o (M)ateria: ").strip().upper()

    if criterio == 'C':
        codigo = input("Codigo del Estudiante: ")
        if codigo in notas:
            notas.pop(codigo)
            guardar_datos_notas()  # Guardar los datos de notas en el archivo CSV
            print("Notas del estudiante eliminadas exitosamente.")
        else:
            print("No hay notas para el estudiante con ese código.")
    elif criterio == 'M':
        codigo = input("Codigo del Estudiante: ")
        materia = input("Materia: ")
        if codigo in notas and materia in notas[codigo]:
            del notas[codigo][materia]
            if not notas[codigo]:
                del notas[codigo]
            guardar_datos_notas()  # Guardar los datos de notas en el archivo CSV
            print("Nota eliminada exitosamente.")
        else:
            print("No se encontró la nota especificada.")
    else:
        print("Opción no válida.")


def modificar_nota():
    print("\n--- Actualizar ---")
    criterio = input("Modificar por (C)odigo o (N)ombre de estudiante: ").strip().upper()

    if criterio == 'C':
        codigo = input("Codigo del Estudiante: ")
        if codigo in notas:
            materia = input("Materia: ")
            if materia in notas[codigo]:
                try:
                    nueva_nota = float(input("Nueva Nota: "))
                except ValueError:
                    print("Nota inválida. Debe ser un número.")
                    return
                notas[codigo][materia] = nueva_nota
                guardar_datos_notas()  # Guardar los datos de notas en el archivo CSV
                print("Nota modificada exitosamente.")
            else:
                print("Materia no encontrada.")
        else:
            print("El estudiante no tiene notas registradas.")
    elif criterio == 'N':
        nombre = input("Nombre del Estudiante: ")
        codigo_encontrado = None
        for codigo, datos in estudiantes.items():
            if datos['Nombre'] == nombre:
                codigo_encontrado = codigo
                break
        if codigo_encontrado and codigo_encontrado in notas:
            materia = input("Materia: ")
            if materia in notas[codigo_encontrado]:
                try:
                    nueva_nota = float(input("Nueva Nota: "))
                except ValueError:
                    print("Nota inválida. Debe ser un número.")
                    return
                notas[codigo_encontrado][materia] = nueva_nota
                guardar_datos_notas()  # Guardar los datos de notas en el archivo CSV
                print("Nota modificada exitosamente.")
            else:
                print("Materia no encontrada.")
        else:
            print("Estudiante no encontrado o sin notas registradas.")
    else:
        print("Opción no válida.")


def buscar_nota():
    print("\n--- Buscar ---")
    codigo = input("Codigo del Estudiante: ")
    if codigo in notas:
        if notas[codigo]:
            print(f"\nNotas para el estudiante {codigo}:")
            for materia, nota in notas[codigo].items():
                print(f"Materia: {materia}, Nota: {nota}")
        else:
            print("El estudiante no tiene notas registradas.")
    else:
        print("No se encontró el estudiante.")


def mostrar_notas():
    print("\n--- Mostrar  ---")
    print(f"{'Codigo':<15} {'Nombre':<15} {'Grado':<15} {'Materia':<20} {'Nota':<10}")
    print("=" * 77)

    notas_mostradas = False
    for codigo, materias in notas.items():
        if codigo in estudiantes:
            estudiante = estudiantes[codigo]
            nombre = estudiante['Nombre']
            grado = estudiante['Grado']
            for materia, nota in materias.items():
                print(f"{codigo:<15} {nombre:<15} {grado:<15} {materia:<20} {nota:<5.2f}")
                notas_mostradas = True

    if not notas_mostradas:
        print("No hay notas para mostrar.")


def menu_control_notas():
    while True:
        print("\n--- Menu Control de Notas ---")
        print("1. Crear")
        print("2. Eliminar")
        print("3. Actualizar")
        print("4. Buscar")
        print("5. Mostrar")
        print("6. Regresar")

        opcion = input("Seleccione una opción: ")
        if opcion == '1':
            agregar_nota()
        elif opcion == '2':
            eliminar_nota()
        elif opcion == '3':
            modificar_nota()
        elif opcion == '4':
            buscar_nota()
        elif opcion == '5':
            mostrar_notas()
        elif opcion == '6':
            break
        else:
            print("Opción no válida. Por favor, intente de nuevo.")


def menu_registro_estudiantes():
    while True:
        mostrar_menu_registro()
        opcion = input("Seleccione una opción: ")
        if opcion == '1':
            crear_estudiante()
        elif opcion == '2':
            eliminar_estudiante()
        elif opcion == '3':
            actualizar_estudiante()
        elif opcion == '4':
            buscar_estudiante()
        elif opcion == '5':
            mostrar_datos()
        elif opcion == '6':
            break
        else:
            print("Opción no válida. Por favor, intente de nuevo.")


def main():
    cargar_datos_estudiantes()  # Cargar datos de estudiantes al inicio del programa
    cargar_datos_notas()  # Cargar datos de notas al inicio del programa
    while True:
        mostrar_menu_principal()
        opcion = input("Seleccione una opción: ")
        if opcion == '1':
            menu_registro_estudiantes()
        elif opcion == '2':
            menu_control_notas()
        elif opcion == '3':
            print("Saliendo...")
            sys.exit()
        else:
            print("Opción no válida. Por favor, intente de nuevo.")


if __name__ == "__main__":
    main()

