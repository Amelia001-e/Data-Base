#archivo de conexion Mongo

from pymongo import MongoClient

#//localhost:27017/

def conexion_mongo(database, collection):
    client = MongoClient('localhost', 27017)
    db = client[database]
    collection = db[collection]
    return client, db, collection

def estudianteMongo(collection, document):
    result = collection.insert_one(document)
    return result.inserted_id
