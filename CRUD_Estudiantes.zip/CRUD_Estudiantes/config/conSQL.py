#archivo de conexion SQL

import pyodbc as py #libreria que se utiliza para conectar sql y realizar operaciones

# DEFINICION DE LAS CONSTANTES A USAR.
_SERVER = "201-01-CTI"
_DB = "CONTROL_ESTUDIANTES"
_USER = "intecap"
_PASS = "intecap.510"
_DRIVER = "ODBC Driver 17 for SQL SERVER"


def estudiantessql(nombre, encargado, grado):
    con = py.connect(f"DRIVER={{{_DRIVER}}};"
                     f"SERVER={_SERVER};"
                     f"DATABASE={_DB};"
                     f"UID={_USER};"
                     f"PWD={_PASS}"
                     )
    try:
        #creacion del cursor
        cursor = con.cursor()
        #consulta de insercion
        consulta = """INSERT INTO ESTUDIANTES (nombre, encargado, grado) VALUES (?, ?, ?) """
        #Ejecutar la consulta
        cursor.execute(consulta,(nombre,encargado,grado))
        #confirmar los cambios
        con.commit()
        print("datos insertados exitosamente")

    except Exception as e:
        print(f"Datos insertados exitosamente")

    finally:
        if cursor:
            cursor.close()
        if con:
            con.close()


if __name__ == "__main__":
    print("este codigo no esta diseñado para ejecutarse libremente. ")