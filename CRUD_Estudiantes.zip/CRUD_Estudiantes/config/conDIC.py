#archivo de configuracion Diccionarios



def crear_estudiante(nombre,encargado,grado):
    estudiante = {}
    return estudiante




    '''"""Función para crear un nuevo estudiante"""
    estudiante["nombre"] = input("Ingrese el nombre del alumno: ").lower()
    estudiante["encargado"] = input("Ingrese el nombre del encargado: ").lower()
    estudiante["grado"] = input(f"Ingrese el grado académico '1ro', '2do', '3ro: ").lower()'''
